﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;

namespace ItemPedido
{
    class Program
    {
        private static CultureInfo cultura = new CultureInfo("en-US");

        static void Main(string[] args)
        {
            string[] lines = System.IO.File.ReadAllLines(@"C:\Temp\ItensPedido.txt");
            PedidoInfo pedido = new PedidoInfo() { IdPedido = Guid.NewGuid(), Items = new List<ItemPedidoInfo>() };

            int linha = 0;
            foreach (string line in lines)
            {
                linha++;
                if (linha <= 10)
                {
                    /* Linhas do cabeçalho */
                    switch (linha)
                    {
                        case 3:
                            pedido.Cliente = line.Replace("Cliente: ", "").Trim();
                            break;
                        case 10:
                            pedido.Versao = line.Replace("Versao: ", "").Trim();
                            break;
                    }
                }
                else if (linha > 10 && linha < 15)
                {
                    /* header da tabela de itens */
                    continue;
                }
                else
                {
                    /* itens do pedido */
                    if (string.IsNullOrEmpty(line) == false)
                    {
                        if (line.Substring(0, 6) == "Total:")
                        {
                            pedido.Total = Convert.ToDecimal(line.Substring(7).ToString(), cultura);
                        }
                        else
                        {
                            ItemPedidoInfo item = QuebraLinha(line);
                            if (item != null) { pedido.Items.Add(item); }
                        }
                    }
                }
            }

            Console.WriteLine(pedido.Cliente);
            Console.WriteLine(pedido.Versao);
            foreach (var x in pedido.Items)
            {
                var texto = string.Format("{0} - {1}: ${2}", x.Item, x.Descricao, x.PrecoCT);
                Console.WriteLine(texto);
            }
            Console.WriteLine(pedido.Total);

            // Keep the console window open in debug mode.
            Console.WriteLine("Press any key to exit.");
            System.Console.ReadKey();
        }

        private static ItemPedidoInfo QuebraLinha(string line)
        {
            try
            {
                return new ItemPedidoInfo()
                {
                    Item = Convert.ToInt32(line.Substring(0, 5).Trim()),
                    Qtde = Convert.ToDecimal(line.Substring(5, 5).Trim(), cultura),
                    Referencia = line.Substring(10, 16).Trim(),
                    Descricao = line.Substring(26, 45).Trim(),
                    Dimensoes = line.Substring(71, 15).Trim(),
                    PrecoCT = Convert.ToDecimal(line.Substring(86).Trim(), cultura)
                };
            }
            catch
            {
                return null;    /* Falhou em alguma conversão */
            }
        }
    }
}
