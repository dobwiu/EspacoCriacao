﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ItemPedido
{

    public class PedidoInfo
    {
        public Guid IdPedido { get; set; }

        public string Cliente { get; set; }

        public string Versao { get; set; }

        public decimal Total { get; set; }

        public ICollection<ItemPedidoInfo> Items { get; set; }
    }


    public class ItemPedidoInfo
    {
        public int IdItem { get; set; }

        public Guid IdPedido { get; set; }

        public int Item { get; set; }

        public decimal Qtde { get; set; }

        public string Referencia { get; set; }

        public string Descricao { get; set; }

        public string Dimensoes { get; set; }

        public decimal PrecoCT { get; set; }
    }
}
